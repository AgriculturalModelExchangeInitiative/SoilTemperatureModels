import setuptools
setuptools.setup(name='SoilTemperature',
version='0.1',
description='',
url='#',
author='loic.manceau@inra.fr',
install_requires=['opencv-python'],
author_email='',
packages=setuptools.find_packages(),
zip_safe=False)