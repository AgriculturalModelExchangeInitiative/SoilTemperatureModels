using System;
using System.Collections.Generic;

public class SoilTemperatureAuxiliary 
{
    
        public SoilTemperatureAuxiliary() { }
    
    
    public SoilTemperatureAuxiliary(SoilTemperatureAuxiliary toCopy, bool copyAll) // copy constructor 
    {
    if (copyAll)
    {
    
    }
    }
}