import  java.io.*;
import  java.util.*;
import java.time.LocalDateTime;

public class SoilTemperatureAuxiliary
{
    
    public SoilTemperatureAuxiliary() { }
    
    public SoilTemperatureAuxiliary(SoilTemperatureAuxiliary toCopy, boolean copyAll) // copy constructor 
    {
        if (copyAll)
        {
        }
    }
}