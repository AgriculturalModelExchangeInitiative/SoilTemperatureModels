#ifndef _SoiltemperatureRate_
#define _SoiltemperatureRate_
#define _USE_MATH_DEFINES
#include <cmath>
#include <iostream>
# include<vector>
# include<string>
using namespace std;
class SoiltemperatureRate
{
    private:
        double heatFlux;
    public:
        SoiltemperatureRate();
        double getheatFlux();
        void setheatFlux(double _heatFlux);

};
#endif