#ifndef _SoiltemperatureAuxiliary_
#define _SoiltemperatureAuxiliary_
#define _USE_MATH_DEFINES
#include <cmath>
#include <iostream>
# include<vector>
# include<string>
using namespace std;
class SoiltemperatureAuxiliary
{
    private:
    public:
        SoiltemperatureAuxiliary();

};
#endif